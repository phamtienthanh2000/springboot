package com.tienthanh.validationdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ValidationdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}

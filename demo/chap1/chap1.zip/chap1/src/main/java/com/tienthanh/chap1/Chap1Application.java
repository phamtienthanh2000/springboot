package com.tienthanh.chap1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chap1Application {

	public static void main(String[] args) {
		SpringApplication.run(Chap1Application.class, args);
	}

}

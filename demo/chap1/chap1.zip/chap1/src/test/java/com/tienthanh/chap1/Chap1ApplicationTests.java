package com.tienthanh.chap1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Chap1ApplicationTests {

	@Test
	void contextLoads() {
	}

}

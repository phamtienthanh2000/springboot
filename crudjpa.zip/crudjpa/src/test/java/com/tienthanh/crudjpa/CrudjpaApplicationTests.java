package com.tienthanh.crudjpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudjpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
